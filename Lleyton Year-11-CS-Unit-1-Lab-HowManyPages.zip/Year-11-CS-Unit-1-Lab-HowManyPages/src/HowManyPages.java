
import java.util.Scanner;
public class HowManyPages {
  public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int myAge;
        System.out.print("Enter your age: ");
        myAge = scan.nextInt();
        int Pages = 100 - myAge;
        System.out.println(myAge + " year olds should read at least " + Pages + " pages before giving up on a book.");
      }
}
